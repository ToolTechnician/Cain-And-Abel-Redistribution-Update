**About Hydrogen**

Hydrogen is a small GDI Malware, with some bytebeat music, many payloads and some shaders. 

IF YOU USE THE SOURCE CODE OF THIS PROJECT, THEN YOUR PROJECT MUST BE OPEN SOURCE!
***
**WARNING**

Please open it in VIRTUAL MACHINE. If you don't, then I AM NOT RESPONSIBLE FOR ANY destruction caused by this malware. 

IF YOU HAVE photosensitive epilepsy, DO NOT EXECUTE THIS MALWARE ANYWHERE!
***
**Screenshots**
![1](/screenshots/1.png "1")
![2](/screenshots/2.png "2")
![3](/screenshots/3.png "3")
![4](/screenshots/4.png "4")
![5](/screenshots/5.png "5")
![6](/screenshots/6.png "6")
***
**Creator and special thanks**

Created by Leo.

Thanks [rCat](https://github.com/srcatt "rCat") for helping and inspiring me!

Also, you can look at his project: [ü.exe](https://github.com/srcatt/u "ü.exe").
